"""Read-only aggregate queue status; never prints addresses or payloads."""
from datetime import datetime, timezone
from sqlalchemy import func, select
from app.db.database import SessionLocal
from app.models.email_outbox import EmailOutbox


def main():
    with SessionLocal() as db:
        rows=db.execute(select(EmailOutbox.status,func.count()).group_by(EmailOutbox.status)).all()
        oldest=db.scalar(select(func.min(EmailOutbox.created_at)).where(EmailOutbox.status=="pending"))
        print("Queue counts:", ", ".join(f"{status}={count}" for status,count in rows) or "empty")
        if oldest:
            print("Oldest pending seconds:", max(0,int((datetime.now(timezone.utc)-oldest).total_seconds())))


if __name__ == "__main__":
    main()
